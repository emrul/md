import "./contextmenu.js";
import "./drag.js";
import * as Application from "./application.js";
import * as Browser from "./browser.js";
import * as Call from "./calls.js";
import * as Clipboard from "./clipboard.js";
import * as Create from "./create.js";
import * as Dialogs from "./dialogs.js";
import * as Events from "./events.js";
import * as Flags from "./flags.js";
import * as Screens from "./screens.js";
import * as System from "./system.js";
import * as IOS from "./ios.js";
import * as Updater from "./updater.js";
import Window from "./window.js";
import * as WML from "./wml.js";
export { Application, Browser, Call, Clipboard, Dialogs, Events, Flags, Screens, System, IOS, Updater, Window, WML };
/**
 * An internal utility consumed by the binding generator.
 *
 * @ignore
 */
export { Create };
export * from "./cancellable.js";
export { setTransport, getTransport, type RuntimeTransport, objectNames, clientId, } from "./runtime.js";
/**
 * Loads a script from the given URL if it exists.
 * Uses HEAD request to check existence, then injects a script tag.
 * Silently ignores if the script doesn't exist.
 */
export declare function loadOptionalScript(url: string): Promise<void>;
