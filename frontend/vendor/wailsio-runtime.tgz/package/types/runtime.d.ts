import { nanoid } from "./nanoid.js";
export { nanoid };
export declare const objectNames: Readonly<{
    Call: 0;
    Clipboard: 1;
    Application: 2;
    Events: 3;
    ContextMenu: 4;
    Dialog: 5;
    Window: 6;
    Screens: 7;
    System: 8;
    Browser: 9;
    CancelCall: 10;
    IOS: 11;
}>;
export declare let clientId: string;
/**
 * RuntimeTransport defines the interface for custom IPC transport implementations.
 * Implement this interface to use WebSockets, custom protocols, or any other
 * transport mechanism instead of the default HTTP fetch.
 */
export interface RuntimeTransport {
    /**
     * Send a runtime call and return the response.
     *
     * @param objectID - The Wails object ID (0=Call, 1=Clipboard, etc.)
     * @param method - The method ID to call
     * @param windowName - Optional window name
     * @param args - Arguments to pass (will be JSON stringified if present)
     * @returns Promise that resolves with the response data
     */
    call(objectID: number, method: number, windowName: string, args: any): Promise<any>;
}
/**
 * Set a custom transport for all Wails runtime calls.
 * This allows you to replace the default HTTP fetch transport with
 * WebSockets, custom protocols, or any other mechanism.
 *
 * @param transport - Your custom transport implementation
 *
 * @example
 * ```typescript
 * import { setTransport } from '/wails/runtime.js';
 *
 * const wsTransport = {
 *   call: async (objectID, method, windowName, args) => {
 *     // Your WebSocket implementation
 *   }
 * };
 *
 * setTransport(wsTransport);
 * ```
 */
export declare function setTransport(transport: RuntimeTransport | null): void;
/**
 * Get the current transport (useful for extending/wrapping)
 */
export declare function getTransport(): RuntimeTransport | null;
/**
 * Creates a new runtime caller with specified ID.
 *
 * @param object - The object to invoke the method on.
 * @param windowName - The name of the window.
 * @return The new runtime caller function.
 */
export declare function newRuntimeCaller(object: number, windowName?: string): (method: number, args?: any) => Promise<any>;
